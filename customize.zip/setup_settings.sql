-- Run this in PhpMyAdmin → stockora_db → SQL tab
-- Creates the app_settings table for customization

CREATE TABLE IF NOT EXISTS `app_settings` (
  `key`   VARCHAR(100) NOT NULL,
  `value` TEXT         NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
