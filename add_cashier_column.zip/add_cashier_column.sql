-- Step 1: Run this in PhpMyAdmin → stockora_db → SQL tab
-- Adds cashier tracking to the sales table

ALTER TABLE sales ADD COLUMN cashier_id INT DEFAULT NULL;
ALTER TABLE sales ADD COLUMN cashier_name VARCHAR(100) DEFAULT NULL;

-- Optional: Link existing sales to a default user (if you want)
-- UPDATE sales SET cashier_id = 1, cashier_name = 'admin' WHERE cashier_id IS NULL;
